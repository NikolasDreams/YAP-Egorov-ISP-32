﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YP_sait.Data.interfaces;
using YP_sait.ViewModels;
// реализует спомощью функций html страницы
namespace YP_sait.Controllers
{
    public class CarsController : Controller{

        private readonly IAllCars _allCars;
        private readonly ICarsCategory _allCategories;

        //обращаемся к интерфейсу вместе с его классом
        public CarsController(IAllCars iAllCars, ICarsCategory iCarsCat)
        {
            _allCars = iAllCars;
            _allCategories = iCarsCat;
        }
        //возращает html страницу
        public ViewResult List(){
            ViewBag.Title = "Страница с автомобилями";
            CarsListViewModel obj = new CarsListViewModel();
            obj.allCars = _allCars.Cars;
            obj.currCategory = "Автомобили";
            return View(obj);
        }
    }
}
