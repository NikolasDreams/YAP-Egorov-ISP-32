﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YP_sait.Data.interfaces;
using YP_sait.Data.Models;
//Репозитории для работы с БД
namespace YP_sait.Data.Repossitory
{
    public class CategoryRepositoty : ICarsCategory
    {
        private readonly AppDBContent appDBContent;

        public CategoryRepositoty(AppDBContent appDBContent)
        {
            this.appDBContent = appDBContent;
        }
        public IEnumerable<Category> AllCategories => appDBContent.Category;
    }
}
