﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YP_sait.Data.Models;

namespace YP_sait.Data.interfaces
{//полочение товаров
   public interface IAllCars
    {   //возращает список товаров из модели car

        IEnumerable<Car> Cars { get; }
        
        IEnumerable<Car> getFavCars {  get;  }
        Car getObjectCar(int carID);

    }
}
