﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YP_sait.Data.Models;

namespace YP_sait.Data.interfaces
{//полочение всех моделей
   public interface ICarsCategory
{
        //возращает все категории из модели category
        IEnumerable<Category> AllCategories { get; }

}
}
