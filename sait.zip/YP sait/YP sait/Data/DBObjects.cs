﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Linq;
using YP_sait.Data.Models;

namespace YP_sait.Data
{
    public class DBObjects
    {
        public static void Initial(AppDBContent content)
        {



            if (!content.Category.Any())
                content.Category.AddRange(Categories.Select(c => c.Value));

            if (!content.Car.Any())
            {
                content.AddRange(
                    new Car
                    {
                        name = "Tesla Model 5",
                        shortDesc = "Быстрый автомобиль",
                        longDesc = "Красивый",
                        img = "https://www.zero2turbo.com/wp-content/uploads/2021/02/tesla-model-x.jpg",
                        price = 20000000,
                        isFavorite = true,
                        available = true,
                        Category = Categories["Электромобили"]
                    },

                 new Car
                 {
                     name = "Lamborghini Urus",
                     shortDesc = "Тихий спокойный",
                     longDesc = "Удобный для города",
                     img = "https://www.fonstola.ru/images/202009/fonstola.ru_407850.jpg",
                     price = 40000000,
                     isFavorite = false,
                     available = true,
                     Category = Categories["Электромобили"]
                 },

                 new Car
                 {
                     name = "BMW x6",
                     shortDesc = "Стильный",
                     longDesc = "Удобный для города",
                     img = "https://aybaz.ru/wp-content/uploads/a/a/0/aa0a7f27d524f40140473957e1362048.jpeg",
                     price = 13000000,
                     isFavorite = true,
                     available = true,
                     Category = Categories["Классические автомобили"]
                 },

                 new Car
                 {
                     name = "Mercedes-AMG CLA 45",
                     shortDesc = "Уютный и большой",
                     longDesc = "Удобный для города",
                     img = "http://www.dragtimes.com/images/28870-2015-Mercedes-Benz-CLA45-AMG.jpg",
                     price = 7000000,
                     isFavorite = false,
                     available = false,
                     Category = Categories["Классические автомобили"]
                 },

                 new Car
                 {
                     name = "Nissan Leaf",
                     shortDesc = "Бесшумный и экономный",
                     longDesc = "Удобный для города",
                     img = "https://avatars.dzeninfra.ru/get-zen_doc/3963198/pub_604f7655e781846a40e53fdd_604f76810a7d51654a059693/scale_1200",
                     price = 12000000,
                     isFavorite = true,
                     available = true,
                     Category = Categories["Классические автомобили"]
                 }

                );
            }
            //content.SaveChanges();
        }

        private static Dictionary<string, Category> category;
        public static Dictionary<string, Category> Categories
        {
            get
            {
                if (category == null)
                {
                    var list = new Category[]
                    {
                         new Category {categoryName = "Электромобили", desc= "Совреенный вид транспорта"},
                        new Category {categoryName = "Классические автомобили", desc= "Машины с двигателем внетреннего згорания"}
                    };

                    category = new Dictionary<string, Category>();
                    foreach(Category el in list)
                        category.Add(el.categoryName, el);
                }
                return category;
            }
        }
    }
}
